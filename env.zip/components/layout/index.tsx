import AuthLayout from './auth';
import SimpleLayout from './simple';

export { AuthLayout, SimpleLayout };