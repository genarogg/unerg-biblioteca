'use client'
import React from 'react'
import Login from "@view/login";

interface loginProps {

}

const login: React.FC<loginProps> = () => {
    return (
        <Login />
    );
}

export default login;